#include <stdio.h> 
#include <math.h> 

int main()
{
	int c, i=7;
	printf("inserire un valore: "); 
	scanf("%d",&c);
		for (i=7; i>=0; i--)
		{
			printf("%d ", (c >> i) & 1);  // SHIFT A DESTRA DI i POSIZIONI E POI and PER VEDERE QUANTO VALE IL BIT
		
		}
		printf(" ");
	return 0;
}

	

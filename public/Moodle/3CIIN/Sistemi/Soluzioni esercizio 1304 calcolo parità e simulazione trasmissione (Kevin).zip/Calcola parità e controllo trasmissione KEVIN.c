#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#define DIM 8
// CALCOLA LA PARITA', SIMULA LA TRASMISSIONE E CONTROLLA SE IL NUMERO ARRIVATO � CORRETTO


int parita(int);
void visualizza(int);
int mask();
int errore(int, int);
int check(int);

int main(){
	srand(time(NULL));
	int n, n_con_p1, m, n_err, p2;
	do{										// LEGGE UN NUMERO TRA 0 E 255
		printf("numero: ");
		scanf("%d",&n);
		fflush(stdin);
	}while(n<0 || n>255);
	printf("byte: ");
	visualizza(n);							// STAMPA IL NUMERO IN BUNARIO
	n_con_p1=parita(n);						// CALCOLA LA PARITA'
	printf("byte con parita: ");
	visualizza(n_con_p1);					// STAMPA IL NUMERO IN BIANARIO
	m=mask();								// SIMULA L'ERRORE DI TRASMISSIONE
	printf("mask: ");
	visualizza(m);							// STAMPA LA MASCHERA PER CREARE L'ERRORE 
	n_err=errore(n_con_p1, m);
	printf("XOR con mask: ");
	visualizza(n_err);
	if(check(n_err)==1)
		printf("\nnumero corrotto");
	else
		printf("\nnumero integro");
	return 0;
}

void visualizza(int n){					// STAMPA IL NUMERO IN BUNARIO
	int i;
	for(i=7; i>=0; i--)
		printf("%d", (n>>i)&1);
	putchar('\n');
}

int parita(int n){						// CALCOLA LA PARITA'
	int i, c=0;
	for(i=7; i>=0; i--)
		if(((n>>i)&1)==1) c++;
	
	if(c%2==1)							// EVENTUALMENTE AGGIUNGE 1 PER PARITA'
		n=n+128;
	return n;
}

int mask(){
	return pow(2, rand()%9);			// SIMULA UN ERRORE
}

int errore(int n, int m){				// AGGIUNGE L'ERRORE AL NUMERO
	return n^m;
}

int check(int n){					// CONTROLLA IL NUMERO IN ARRIVO
	int i, c=0, p;
	for(i=0; i<7; i++)
		if(((n>>i)&1)==1) c++;		// CONTA I BIT A 1
	p=n>>7&1;
	if(p==c%2) return 0;			// RETURN 1 SE C'� STATO ERRORE 0 SE NON C'E' STATO ERRORE
	else return 1;	
}
